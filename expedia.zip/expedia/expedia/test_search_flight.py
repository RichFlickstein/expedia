from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from expedia.helpers import helper_selenium_functions
from expedia.helpers import helper_general_functions
import urllib.parse
import unittest
from expedia.daos.flights_homepage import FlightsHomePage

"""
Suite of tests for Searching Flights
Author; Rich Flickstein
Currently, contains the setup, a single test, and teardown and tests run serially on local machine

Related future tests
    Future Functional Tests:
        Select origin and destination from dropdown options
        Select dates from calendar
    Future Validation Tests:
        Select the same value for origin and destination
        Search without entering dates
        Search illegal date range
    
"""

class Tests(unittest.TestCase):

    driver = None

    def setUp(self):

        # Instantiate driver and begin navigation
        global driver
        driver = webdriver.Chrome(executable_path=r'C:\dev\QA\trunk\expedia\chromedriver')
        url = 'https://www.expedia.com/'
        driver.get(url)
        driver.set_window_size(1920, 1080)
        driver.maximize_window()

    def tearDown(self):
        global driver
        driver.close()

    def test_round_trip_anonymous_user(self):

        """
        Test environment; Chrome 1920 x 1080
        Test Operation: Search Flight home page
        Data: Round trip (default) with typed (VS selected) entry of origin and destination
        User: Anonymous user (not logged in)
        """

        # DATA - This could also be read in from external source
        departing_date = helper_general_functions.get_now_plus_days_as_mmddYYYY(1)
        returning_date = helper_general_functions.get_now_plus_days_as_mmddYYYY(8)
        origin = 'LAX'
        destination = 'CHO'

        # Start
        FlightsHomePage.click_clight_button(driver)
        FlightsHomePage.populate_origin_input(driver, origin)
        FlightsHomePage.populate_destination_input(driver, destination)
        FlightsHomePage.populate_departing_input(driver, departing_date)
        FlightsHomePage.populate_returning_input(driver, returning_date)
        FlightsHomePage.click_submit(driver)

        # Get current URL
        current_url = driver.current_url
        current_url = str.lower(urllib.parse.unquote(current_url))

        # Expedia url construction is apparently inconsistent
        # so checking for certain values in the link rather than checking the value of the complete url
        expected_substring = "https://www.expedia.com/flights-search?flight-type=on&stardate={0}" \
                             "&enddate={1}&mode=search&trip=roundtrip".format(departing_date, returning_date)

        # Assertions

        # URL should contain expected text
        assert helper_general_functions.string_contains_expected_substring(current_url, expected_substring), "URL found {0} does not contain {1}".format(current_url, expected_substring)

        # Flight offers should be displayed

        offers = driver.find_elements_by_xpath("//li[@data-test-id='offer-listing']")
        assert len(offers) > 0, "Offers should be present on the page"
