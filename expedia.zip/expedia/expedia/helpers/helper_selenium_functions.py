from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as ec


def wait_for_visible_by_xpath(driver, xpath, timer=30):
    loc = By.XPATH, xpath
    wait = WebDriverWait(driver, timer)
    we = wait.until(ec.visibility_of_element_located(loc), 'Could not find element {0}'.format(loc))
    return we


def wait_for_visible_by_id(driver, element_id, timer=30):
    loc = By.ID, element_id
    wait = WebDriverWait(driver, timer)
    we = wait.until(ec.visibility_of_element_located(loc), 'Could not find element {0}'.format(loc))
    return we

