import datetime
from datetime import timedelta


def get_now_as_mmddYYYY():
    # Example 06/23/2017
    now = datetime.datetime.now()
    now_formatted = now.strftime("%m/%d/%Y")
    return now_formatted


def get_now_minus_days_as_mmddYYYY(days_to_subtract=7):
    # Example 06/23/2017
    my_date = datetime.datetime.now() - timedelta(days=days_to_subtract)
    my_date_formatted = my_date.strftime("%m/%d/%Y")
    return my_date_formatted


def get_now_plus_days_as_mmddYYYY(days_to_add=7):
    # Example 06/23/2017
    my_date = datetime.datetime.now() + timedelta(days=days_to_add)
    my_date_formatted = my_date.strftime("%m/%d/%Y")
    return my_date_formatted


def string_contains_expected_substring(container_string, expected_substring):
    if container_string is None:
        return False
    container_string = container_string.lower()
    expected_substring = expected_substring.lower()
    found = container_string.find(expected_substring)
    if found == -1:
        return False
    else:
        return True
