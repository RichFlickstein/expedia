class Header:

    def __init__(self):
        pass

    # Locators

    # Methods
