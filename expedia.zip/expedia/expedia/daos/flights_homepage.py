from expedia.daos.header import Header
from expedia.daos.tabs import Tabs
from expedia.daos.flights_search_form import FlightsSearchForm


class FlightsHomePage(Header, Tabs, FlightsSearchForm):
    def __init__(self):
        pass

    # Locators
