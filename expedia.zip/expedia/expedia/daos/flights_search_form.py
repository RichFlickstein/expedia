from selenium.webdriver.common.keys import Keys
from expedia.helpers import helper_selenium_functions


class FlightsSearchForm:

    def __init__(self):
        pass

    # Locators
    flight_origination_input_loc = 'flight-origin-hp-flight'
    flight_destination_input_loc = 'flight-destination-hp-flight'
    flight_departing_input_loc = 'flight-departing-hp-flight'
    flight_returning_input_loc = 'flight-returning-hp-flight'
    flights_hp_search_button_loc = "//form[@id='gcw-flights-form-hp-flight']//button[@type='submit']"

    # Methods
    @staticmethod
    def populate_origin_input(driver, origin):
        # Return element once it is visible
        we = helper_selenium_functions.wait_for_visible_by_id(driver, FlightsSearchForm.flight_origination_input_loc)
        we.send_keys(Keys.CONTROL + 'a')
        we.send_keys(origin)
        we.send_keys(Keys.TAB)

    @staticmethod
    def populate_destination_input(driver, destination):
        # Return element once it is visible
        we = helper_selenium_functions.wait_for_visible_by_id(driver, FlightsSearchForm.flight_destination_input_loc)
        we.send_keys(Keys.CONTROL + 'a')
        we.send_keys(destination)
        we.send_keys(Keys.TAB)

    @staticmethod
    def populate_departing_input(driver, departing_date):
        # Return element once it is visible
        we = helper_selenium_functions.wait_for_visible_by_id(driver, FlightsSearchForm.flight_departing_input_loc)
        we.send_keys(Keys.CONTROL + 'a')
        we.send_keys(departing_date)

    @staticmethod
    def populate_returning_input(driver, returning_date):
        # Return element once it is visible
        we = helper_selenium_functions.wait_for_visible_by_id(driver, FlightsSearchForm.flight_returning_input_loc)
        we.send_keys(Keys.CONTROL + 'a')
        we.send_keys(returning_date)

    @staticmethod
    def click_submit(driver):
        # Return element once it is visible
        we = helper_selenium_functions.wait_for_visible_by_xpath(driver, FlightsSearchForm.flights_hp_search_button_loc)
        we.click()


