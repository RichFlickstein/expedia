class FlightsSearchForm:

    def __init__(self):
        pass

    # Locators
    flight_origination_input_loc = 'flight-origin-hp-flight'
    flight_destination_input_loc = 'flight-destination-hp-flight'
    flight_departing_input_loc = 'flight-departing-hp-flight'
    flight_returning_input_loc = 'flight-returning-hp-flight'
    flights_hp_search_button_loc = "//form[@id='gcw-flights-form-hp-flight']//button[@type='submit']"
