class Tabs:
    def __init__(self):
        pass

    # Locators
    flights_tab_button_loc = 'tab-flight-tab-hp'
