from expedia.helpers import helper_selenium_functions


class Tabs:
    def __init__(self):
        pass

    # Locators
    flights_tab_button_loc = 'tab-flight-tab-hp'

    # Methods

    @staticmethod
    def click_clight_button(driver):

        # Return element once it is visible
        we = helper_selenium_functions.wait_for_visible_by_id(driver, Tabs.flights_tab_button_loc)
        we.click()
